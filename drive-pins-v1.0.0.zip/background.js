chrome.runtime.onInstalled.addListener(() => {
	chrome.contextMenus.create({
		id: "drive-pins-context-toggle",
		title: "Pin / Unpin in Drive Pins",
		contexts: ["page", "link"],
		documentUrlPatterns: ["https://drive.google.com/*"]
	}), console.log("[DrivePins] Service worker installed and context menu created");
}), chrome.contextMenus.onClicked.addListener(async (e, t) => {
	if (e.menuItemId === "drive-pins-context-toggle" && t?.id) try {
		await chrome.tabs.sendMessage(t.id, { action: "context-menu-pin" });
	} catch (e) {
		console.warn("[DrivePins] Failed to dispatch context menu action to tab:", e);
	}
});
